from django.contrib import admin
from .models import *

admin.site.register(PersonalInfo)
admin.site.register(Skill)
admin.site.register(Project)
admin.site.register(Education)
admin.site.register(WorkExperience)
admin.site.register(Certificate)
